package com.samco.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "samco1")
public class Samco {
	
	@Id
	private String client_id;
	private String password;
	private int doy;

	public Samco() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Samco(String client_id, String password, int doy) {
		super();
		this.client_id = client_id;
		this.password = password;
		this.doy = doy;
	}

	public String getClient_id() {
		return client_id;
	}

	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getDoy() {
		return doy;
	}

	public void setDoy(int doy) {
		this.doy = doy;
	}

	@Override
	public String toString() {
		return "Samco [client_id=" + client_id + ", password=" + password + ", doy=" + doy + "]";
	}

}
