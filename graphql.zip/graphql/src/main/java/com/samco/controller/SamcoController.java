package com.samco.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import com.samco.model.Samco;
import com.samco.repository.SamcoRepository;

@Controller
public class SamcoController {
	private final SamcoRepository samcoRepository;
	
	public SamcoController(SamcoRepository samcoRepository) {
		this.samcoRepository=samcoRepository;
	}
	
	@QueryMapping
	List<Samco> findAllSamco(){
		return samcoRepository.findAll();
	}
	
	@QueryMapping
	Optional<Samco> findById(@Argument String id) {
		return samcoRepository.findById(id);
	}
	
	@MutationMapping
	public Samco addUser(@Argument SamcoInput samco) {
		samcoRepository.findById(samco.client_id());
		Samco a = new Samco(samco.client_id(),samco.password(),samco.doy());
		return samcoRepository.save(a);
	}
	
	record SamcoInput(String client_id,String password,int doy) {}
	
	
}
