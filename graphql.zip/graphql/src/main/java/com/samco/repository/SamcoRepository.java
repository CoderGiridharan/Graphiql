package com.samco.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.samco.model.Samco;

public interface SamcoRepository extends MongoRepository<Samco, String>{

}
